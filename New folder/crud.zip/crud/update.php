<!DOCTYPE html>
<html lang="en">
    <head>
        <title></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link href="css/style.css" rel="stylesheet">
    </head>
    <body>
    

<form method="post">
<input type="text" name="name" value="">
<input type="email" name="email" value="">    
<input type="password" name="pass" value="">    
<button type="submit" name="btn">Create</button>
</form>






<?php 
$con = mysqli_connect("localhost","root","","crud") or die("Connection Lost"); 
if(isset($_POST['btn'])){
$id = $_GET["id"];
$name = $_POST['name'];
$email = $_POST['email'];
$pass = $_POST['pass'];

$query = mysqli_query($con,"UPDATE c SET Id=$id, Name='$name', Email='$email', Password='$pass' WHERE Id=$id");


header('Location:read.php');


}

?>
    </body>
</html>